package io.example.professionaltaxportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfessionaltaxportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
