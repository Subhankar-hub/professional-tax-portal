package io.example.professionaltaxportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfessionaltaxportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfessionaltaxportalApplication.class, args);
	}

}
